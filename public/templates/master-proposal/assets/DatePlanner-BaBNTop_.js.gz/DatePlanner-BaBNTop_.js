import{a as i,j as e,m as h,A as U}from"./motion-C6c_ebrr.js";import{T as q}from"./Toast-C6zIqySg.js";import{c as l,g as C,H as $,P as A}from"./index-yraCl_y4.js";import"./vendor-B945N0Jz.js";/**
 * @license lucide-react v0.563.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const K=[["path",{d:"M12 7v14",key:"1akyts"}],["path",{d:"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",key:"ruj8y"}]],I=l("book-open",K);/**
 * @license lucide-react v0.563.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G=[["path",{d:"M10 12h4",key:"a56b0p"}],["path",{d:"M10 8h4",key:"1sr2af"}],["path",{d:"M14 21v-3a2 2 0 0 0-4 0v3",key:"1rgiei"}],["path",{d:"M6 10H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2",key:"secmi2"}],["path",{d:"M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16",key:"16ra0t"}]],E=l("building-2",G);/**
 * @license lucide-react v0.563.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const X=[["path",{d:"M12 6v6l4 2",key:"mmk7yg"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],Y=l("clock",X);/**
 * @license lucide-react v0.563.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const J=[["path",{d:"M10 2v2",key:"7u0qdc"}],["path",{d:"M14 2v2",key:"6buw04"}],["path",{d:"M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1",key:"pwadti"}],["path",{d:"M6 2v2",key:"colzsn"}]],L=l("coffee",J);/**
 * @license lucide-react v0.563.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Q=[["path",{d:"M12.67 19a2 2 0 0 0 1.416-.588l6.154-6.172a6 6 0 0 0-8.49-8.49L5.586 9.914A2 2 0 0 0 5 11.328V18a1 1 0 0 0 1 1z",key:"18jl4k"}],["path",{d:"M16 8 2 22",key:"vp34q"}],["path",{d:"M17.5 15H9",key:"1oz8nu"}]],_=l("feather",Q);/**
 * @license lucide-react v0.563.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Z=[["line",{x1:"6",x2:"10",y1:"11",y2:"11",key:"1gktln"}],["line",{x1:"8",x2:"8",y1:"9",y2:"13",key:"qnk9ow"}],["line",{x1:"15",x2:"15.01",y1:"12",y2:"12",key:"krot7o"}],["line",{x1:"18",x2:"18.01",y1:"10",y2:"10",key:"1lcuu1"}],["path",{d:"M17.32 5H6.68a4 4 0 0 0-3.978 3.59c-.006.052-.01.101-.017.152C2.604 9.416 2 14.456 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.414-1.414A2 2 0 0 1 9.828 16h4.344a2 2 0 0 1 1.414.586L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.545-.604-6.584-.685-7.258-.007-.05-.011-.1-.017-.151A4 4 0 0 0 17.32 5z",key:"mfqc10"}]],O=l("gamepad-2",Z);/**
 * @license lucide-react v0.563.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ee=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],ae=l("loader-circle",ee);/**
 * @license lucide-react v0.563.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const te=[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]],le=l("send",te);/**
 * @license lucide-react v0.563.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const se=[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]],ne=l("sparkles",se);/**
 * @license lucide-react v0.563.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const re=[["path",{d:"M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",key:"qn84l0"}],["path",{d:"M13 5v2",key:"dyzc3o"}],["path",{d:"M13 17v2",key:"1ont0d"}],["path",{d:"M13 11v2",key:"1wjjxi"}]],y=l("ticket",re),x={recipientEmail:"rabbiahmedfahim44@gmail.com",toName:"Rodney (The Best Boyfriend)",fromName:"Sherry (Your Valentine)",fromLabel:"Sherry"};let b=null;function oe(){var s,d,p,m;if(b)return b;const c=C();return b={recipientEmail:((s=c.recipientEmail)==null?void 0:s.trim())||x.recipientEmail,toName:((d=c.toName)==null?void 0:d.trim())||x.toName,fromName:((p=c.fromName)==null?void 0:p.trim())||x.fromName,fromLabel:((m=c.fromLabel)==null?void 0:m.trim())||x.fromLabel},b}const P=[e.jsx(_,{className:"w-6 h-6"}),e.jsx(L,{className:"w-6 h-6"}),e.jsx(A,{className:"w-6 h-6"}),e.jsx(O,{className:"w-6 h-6"}),e.jsx(y,{className:"w-6 h-6"}),e.jsx(I,{className:"w-6 h-6"}),e.jsx(E,{className:"w-6 h-6"})],ie=[{id:"massage",label:"Massage & Class",icon:e.jsx(_,{className:"w-6 h-6"}),planTitle:"The Stress Melter",planDescription:"Multitasking at its finest. While you attend your online class, I'll be your personal masseur. I'll give you a full body massage to help you relax and recharge before you have to clock in at 5 PM.",budget:"Free"},{id:"preshift",label:"Pre-Work Recharge",icon:e.jsx(L,{className:"w-6 h-6"}),planTitle:"The 30-Minute Power Date",planDescription:"I know you're busy between class and work. I'll meet you right in that gap. I'll bring you food/coffee, we'll sit for a bit, and I'll hype you up before your 5 PM shift starts.",budget:"$"},{id:"color",label:"Color Challenge",icon:e.jsx(A,{className:"w-6 h-6"}),planTitle:"The Color Snack Challenge",planDescription:"We pick a random color (Pink? Blue? Red?) and head to the nearest convenience store. We can only buy and eat snacks/drinks that match that color!",budget:"$$"},{id:"arcade",label:"Arcade & Ice Cream",icon:e.jsx(O,{className:"w-6 h-6"}),planTitle:"Retro Arcade Duel",planDescription:"We hit the arcade. Air hockey, basketball, and crane games. Loser buys the winner ice cream afterwards (but let's be honest, I'll buy it anyway).",budget:"$$"},{id:"movie",label:"Laptop Cinema",icon:e.jsx(y,{className:"w-6 h-6"}),planTitle:"Dorm/Room Movie Night",planDescription:"I'll bring the popcorn and snacks. We build a blanket nest and watch that movie you've been wanting to see on your laptop.",budget:"$"},{id:"study",label:"Study & Sip",icon:e.jsx(I,{className:"w-6 h-6"}),planTitle:"Coffee Shop Focus Date",planDescription:"We'll find a quiet corner at a cute cafe. I'll buy the coffee/boba, you bring the notes. 50% studying, 50% holding hands under the table.",budget:"$"},{id:"capitaltown",label:"Capital Town",icon:e.jsx(E,{className:"w-6 h-6"}),planTitle:"Capital Town Anniversary Redo",planDescription:"We missed going here for our anniversary, but we're making up for it now. Let's finally have that date at Capital Town Pampanga. We'll walk around, grab food, and enjoy the vibe before your schedule gets busy.",budget:"$$",isSpecial:!0}],he=()=>{var j,T,S;const s=C().datePlanner||{},d=((j=s.heading)==null?void 0:j.trim())||"Let's Plan Our Date Together",p=((T=s.subtitle)==null?void 0:T.trim())||"Pick what your heart desires.",m=((S=s.sendButtonLabel)==null?void 0:S.trim())||"Send Ticket",v=s.options&&s.options.length?s.options.map((a,n)=>({id:a.id||`custom-${n}`,label:a.label,planTitle:a.planTitle,planDescription:a.planDescription,budget:a.budget||"$",isSpecial:a.isSpecial,icon:P[n%P.length]})):ie,[u,B]=i.useState(null),[r,W]=i.useState("Afternoon (Before Work)"),[R,k]=i.useState(!1),[V,f]=i.useState(""),[z,w]=i.useState("success"),[o,N]=i.useState(!1),t=v.find(a=>a.id===u),F=async()=>{if(!t||o)return;N(!0);const a=oe(),n=a.recipientEmail,M=`Date Ticket: ${t.planTitle}`,g=`
🎫  OFFICIAL DATE TICKET
----------------------------------------

📅  DATE ISSUED: ${new Date().toLocaleDateString("en-US",{month:"long",day:"numeric",year:"numeric"})}
🎟️  TICKET ID:   #${String(Math.floor(Math.random()*1e4)).padStart(4,"0")}

----------------------------------------

👤  TO:   ${a.toName}
👤  FROM: ${a.fromName}

----------------------------------------

📍  EVENT
${t.planTitle}

📝  DETAILS
${t.planDescription}

🕐  TIME
${r}

💰  BUDGET
${t.isSpecial?"Extra Special ✨":t.budget}

----------------------------------------

✅  ADMISSION INCLUDES:
• One Couple (VIP Access)
• Unlimited Hugs & Kisses
• 100% Quality Time

----------------------------------------

💳  PAYMENT: Paid in Full with Love ❤️

Reply to confirm! 💌

Love always,
${a.fromLabel}
    `,H=`<pre style="font-family:ui-monospace,monospace;white-space:pre-wrap;font-size:14px;line-height:1.5;">${g.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}</pre>`;try{if(!(await fetch("/api/send-ticket",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({to:n,subject:M,text:g,html:H})})).ok)throw new Error("send failed");w("success"),f(`Date ticket sent! "${t.planTitle}" is on its way to ${a.toName.split(" (")[0]}!`),k(!0)}catch{const D=`mailto:${n}?subject=${encodeURIComponent(M)}&body=${encodeURIComponent(g)}`;window.location.href=D,w("error"),f("Auto-send is unavailable right now, opening your mail app instead."),k(!0)}finally{N(!1)}};return e.jsxs("div",{className:"w-full max-w-6xl mx-auto text-center px-4",children:[e.jsxs("div",{className:"mb-12",children:[e.jsx("h2",{className:"font-serif text-3xl md:text-5xl mb-4 text-love-text dark:text-love-dark-text","data-bb-key":"datePlanner.heading","data-bb-label":"Date planner heading",children:d}),e.jsx("p",{className:"text-love-accent dark:text-love-dark-accent/80 mb-2","data-bb-key":"datePlanner.subtitle","data-bb-label":"Date planner subtitle",children:p})]}),e.jsx("div",{className:"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-12",children:v.map((a,n)=>e.jsxs(h.button,{onClick:()=>B(a.id),className:`
              relative p-6 rounded-xl border transition-all duration-300
              flex flex-col items-center gap-3 group
              ${a.isSpecial?"col-span-1 sm:col-span-2 lg:col-span-3 border-amber-400/50 bg-amber-50/50 dark:bg-amber-900/10 dark:border-amber-500/30":u===a.id?"border-love-accent bg-love-accent/5 dark:bg-love-dark-accent/10 shadow-lg scale-[1.02]":"border-love-accent/20 bg-white/40 dark:bg-love-dark-card/30 hover:border-love-accent/50 dark:hover:border-love-dark-accent/50 backdrop-blur-sm"}
            `,whileHover:{y:-5},whileTap:{scale:.95},animate:a.isSpecial?{boxShadow:["0px 0px 0px rgba(251, 191, 36, 0)","0px 0px 15px rgba(251, 191, 36, 0.3)","0px 0px 0px rgba(251, 191, 36, 0)"]}:{},transition:a.isSpecial?{duration:2,repeat:1/0}:{},children:[a.isSpecial&&e.jsx("div",{className:"absolute top-3 right-3 text-amber-500 animate-pulse",children:e.jsx(ne,{className:"w-4 h-4"})}),e.jsx("div",{className:`
              p-3 rounded-full transition-colors duration-300
              ${a.isSpecial?"bg-amber-100 text-amber-600 dark:bg-amber-900/40 dark:text-amber-400":u===a.id?"bg-love-accent text-white dark:bg-love-dark-accent dark:text-love-dark-bg":"bg-love-accent/10 text-love-accent dark:bg-love-dark-accent/10 dark:text-love-dark-accent group-hover:bg-love-accent group-hover:text-white"}
            `,children:a.icon}),e.jsxs("div",{className:"flex flex-col",children:[e.jsx("span",{className:`font-serif text-lg leading-tight ${a.isSpecial?"font-bold text-amber-800 dark:text-amber-200":"text-love-text dark:text-love-dark-text"}`,"data-bb-key":"datePlanner.options","data-bb-index":n,"data-bb-label":`Date option ${n+1} — card label`,children:a.label}),e.jsx("span",{className:"text-xs uppercase tracking-wider text-love-accent/60 dark:text-love-dark-accent/60 mt-2",children:a.isSpecial?"Extra Special":`Budget: ${a.budget}`})]})]},a.id))}),e.jsx("div",{className:"min-h-[450px] flex justify-center items-start",children:e.jsx(U,{mode:"wait",children:t?e.jsx(h.div,{initial:{opacity:0,rotateX:-90,y:-20},animate:{opacity:1,rotateX:0,y:0},exit:{opacity:0,rotateX:90,y:20},transition:{type:"spring",damping:20},className:"relative w-full max-w-md mx-auto",children:e.jsxs("div",{className:`
                 rounded-xl overflow-hidden shadow-2xl border-2 border-dashed relative z-10
                 ${t.isSpecial?"bg-amber-50 dark:bg-[#1a1500] border-amber-400 dark:border-amber-600":"bg-love-card dark:bg-love-dark-card border-love-accent/30 dark:border-love-dark-accent/30"}
              `,children:[e.jsxs("div",{className:`
                  p-4 text-white flex justify-between items-center
                  ${t.isSpecial?"bg-gradient-to-r from-amber-500 to-orange-500":"bg-love-accent dark:bg-love-dark-accent dark:text-love-dark-bg"}
                `,children:[e.jsx("span",{className:"text-xs font-bold tracking-[0.2em] uppercase",children:"Admit One"}),e.jsx($,{className:"w-4 h-4 fill-current"}),e.jsx("span",{className:"text-xs font-bold tracking-[0.2em] uppercase",children:t.isSpecial?"VIP Date":"Date Night"})]}),e.jsxs("div",{className:"p-8 text-center relative",children:[e.jsx("div",{className:"absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none",children:e.jsx($,{className:"w-48 h-48"})}),e.jsx("h3",{className:"font-serif text-2xl md:text-3xl text-love-text dark:text-love-dark-text mb-4",children:t.planTitle}),e.jsx("p",{className:"text-sm md:text-base text-love-text/70 dark:text-love-dark-text/70 leading-relaxed mb-6",children:t.planDescription}),e.jsxs("div",{className:"mb-6 p-4 bg-love-bg dark:bg-black/20 rounded-lg border border-love-accent/10 dark:border-love-dark-accent/10",children:[e.jsxs("div",{className:"flex items-center justify-center gap-2 mb-2 text-love-accent dark:text-love-dark-accent",children:[e.jsx(Y,{className:"w-4 h-4"}),e.jsx("span",{className:"text-xs font-bold uppercase tracking-widest",children:"Select Time"})]}),e.jsxs("select",{value:r,onChange:a=>W(a.target.value),className:"w-full bg-white dark:bg-love-dark-card border border-love-accent/20 dark:border-love-dark-accent/20 rounded px-3 py-2 text-sm text-love-text dark:text-love-dark-text focus:outline-none focus:ring-1 focus:ring-love-accent",children:[e.jsx("option",{value:"Online Class (Before 5 PM)",children:"During Online Class (Before 5 PM)"}),e.jsx("option",{value:"Morning (10:00 AM - 12:00 PM)",children:"Morning (10 AM - 12 PM)"}),e.jsx("option",{value:"Lunch Break (12:00 PM - 2:00 PM)",children:"Lunch Break (12 PM - 2 PM)"}),e.jsx("option",{value:"Early Afternoon (2:00 PM - 4:00 PM)",children:"Early Afternoon (2 PM - 4 PM)"}),e.jsx("option",{value:"After Work (After 5:00 PM)",children:"After Work (Post 5 PM)"}),e.jsx("option",{value:"Weekend (All Day)",children:"Weekend (All Day)"})]}),r.includes("Morning")||r.includes("Afternoon")||r.includes("Lunch")||r.includes("Class")?e.jsx("p",{className:"mt-2 text-[10px] text-love-accent dark:text-love-dark-accent",children:"*Will ensure you're ready for work by 5:00 PM"}):null]}),e.jsx("div",{className:"w-full h-px bg-love-accent/20 dark:bg-love-dark-accent/20 mb-6"}),e.jsxs(h.button,{onClick:F,disabled:o,className:`
                      w-full py-4 rounded-lg flex items-center justify-center gap-3 font-medium uppercase tracking-widest text-xs transition-colors shadow-lg disabled:opacity-70 disabled:cursor-not-allowed
                      ${t.isSpecial?"bg-amber-600 text-white hover:bg-amber-700":"bg-love-text dark:bg-love-dark-text text-white dark:text-love-dark-bg hover:bg-love-accent dark:hover:bg-love-dark-accent"}
                    `,whileHover:{scale:o?1:1.02},whileTap:{scale:o?1:.98},children:[o?e.jsx(ae,{className:"w-4 h-4 animate-spin"}):e.jsx(le,{className:"w-4 h-4"}),e.jsx("span",{"data-bb-key":"datePlanner.sendButtonLabel","data-bb-label":"Send-ticket button text",children:o?"Sending…":m})]}),e.jsx("p",{className:"mt-4 text-[10px] text-love-text/40 dark:text-love-dark-text/40 uppercase",children:t.isSpecial?"One Time Special Offer":"Valid for 1 Romantic Date"})]})]})},"ticket"):e.jsxs(h.div,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},className:"flex flex-col items-center justify-center py-12 text-love-text/30 dark:text-love-dark-text/30",children:[e.jsx(y,{className:"w-16 h-16 mb-4 opacity-50",strokeWidth:1}),e.jsx("p",{className:"text-sm uppercase tracking-widest",children:"Select an option above"})]},"empty")})}),e.jsx(q,{message:V,type:z,duration:4e3,isVisible:R,onClose:()=>k(!1)})]})};export{he as DatePlanner};
